import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from net.utils.tgcn import ConvTemporalGraphical
from net.functions import ReverseLayerF
# from embed_stgcn_into_mmdDA import mmd
import random


class Model_tea2(nn.Module):
    r"""Spatial temporal graph convolutional networks.

    Args:
        in_channels (int): Number of channels in the input data
        num_class (int): Number of classes for the classification task
        edge_importance_weighting (bool): If ``True``, adds a learnable
            importance weighting to the edges of the graph
        **kwargs (optional): Other parameters for graph convolution units

    Shape:
        - Input: :math:`(N, in_channels, T_{in}, V_{in}, M_{in})`
        - Output: :math:`(N, num_class)` wheretorch.nn
            :math:`N` is batch size,
            :math:`T_{in}` is a length of input sequence,
            :math:`V_{in}` is the number of graph nodes,
            :math:`M_{in}` is the number of instance in a frame.
    """

    def __init__(self, in_channels, num_class, edge_importance_weighting, **kwargs) -> object:
        super().__init__()

        # load adjacent matrix A, A needs to add the identity matrix, that is, diagonal of A should be 1.
        # A = np.ones([116, 116])
        # a1_adj_matrix_pc_aal.npy
        # a2_adj_matrix_SR_aal.npy
        # a3_adj_matrix_global_aal.npy
        # a4_adj_matrix_global_topk_aal.npy
        # a5_adj_matrix_pc_topk_aal.npy
        A = np.load('/shenlab/lab_stor4/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/a1_adj_matrix_pc_aal.npy')
        # A = np.load('/home/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/a1_adj_matrix_pc_aal.npy')

        Dl = np.sum(A, 0)
        num_node = A.shape[0]
        Dn = np.zeros((num_node, num_node))
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A), Dn)  # DAD.shape: (node_num, node_num)

        temp_matrix = np.zeros((1, A.shape[0], A.shape[0]))
        temp_matrix[0] = DAD
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A)  # A.shape: torch.Size([1, node_num, node_num])

        # build networks (number of layers, final output features, kernel size)
        spatial_kernel_size = A.size(0)  # spatial_kernel_size = 1**
        temporal_kernel_size = 11  # update temporal kernel size
        kernel_size = (temporal_kernel_size, spatial_kernel_size)  # kernel_size = (11, 1)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}  # kwargs0: {}
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 16, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            # st_gcn(64, 128, kernel_size, 2, **kwargs),
            # st_gcn(128, 128, kernel_size, 1, **kwargs),
            # st_gcn(128, 128, kernel_size, 1, **kwargs),
            # st_gcn(128, 256, kernel_size, 2, **kwargs),
            # st_gcn(256, 256, kernel_size, 1, **kwargs),
            # st_gcn(256, 256, kernel_size, 1, **kwargs),
        ))

        # initialize parameters for edge importance weighting
        if edge_importance_weighting:
            self.edge_importance = nn.ParameterList([
                nn.Parameter(torch.ones(self.A.size()))
                for i in self.st_gcn_networks
            ])
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)  # output: [1, 1, 1, 1, ...]

        # fcn for prediction (**number of fully connected layers**)
        self.cls_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.cls_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.cls_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.cls_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.cls_sig = nn.Sigmoid()

        self.domain_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.domain_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.domain_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.domain_fcn4 = nn.Conv2d(64, 1, kernel_size=1)
        self.domain_sig = nn.Sigmoid()

    def forward(self, data, alpha):  # x.shape: torch.Size([bs, 1, 200, 116, 1]), where 64 is batch size
        N, C, T, V, M = data.size()  # N=bs, C=1, T=W(e.g., 200), V=116, M=1
        data = data.permute(0, 4, 3, 1, 2).contiguous()  # torch.Size([bs, 1, 116, 1, 200])
        data = data.view(N * M, V * C, T)  # torch.Size([bs*1, 116*1, 200])
        data = self.data_bn(data.float())  # torch.Size([bs*1, 116*1, 200])
        data = data.view(N, M, V, C, T)  # torch.Size([bs, 1, 116, 1, 200])
        data = data.permute(0, 1, 3, 4, 2).contiguous()  # torch.Size([bs, 1, 1, 200, 116])
        data = data.view(N * M, C, T, V)  # torch.Size(1*bs, 1, 200, 116])

        for gcn, importance in zip(self.st_gcn_networks, self.edge_importance):
            data, _ = gcn(data, self.A * importance)  # [bs, 16, 200, 116]

        # ------------------------------------------------------------------------------
        # class prediction
        data = data.mean(axis=3)  # [bs, 16, 200]
        feature_data = data.view(data.size(0), -1)  # [bs, 3200]
        data = data.view(data.size(0), -1)  # [bs, 3200]
        data = data.view(N, M, -1, 1, 1).mean(dim=1)  # [64, 3200, 1, 1]
        data = self.cls_fcn1(data)  # [64, 1024, 1, 1]
        data = self.cls_fcn2(data)  # [64, 512, 1, 1]
        data = self.cls_fcn3(data)  # [64, 64, 1, 1]
        data = self.cls_fcn4(data)  # [64, 1, 1, 1]
        data = self.cls_sig(data)
        data_probs_pred = data.view(data.size(0), -1)  # [64, 1]

        # ------------------------------------------------------------------------------
        # domain prediction
        reverse_feature_data = ReverseLayerF.apply(feature_data, alpha)  # feature should be (bs, xxx)
        reverse_feature_data = reverse_feature_data.view(N, M, -1, 1, 1).mean(dim=1)  # torch.Size([64, xx])
        reverse_feature_data = self.domain_fcn1(reverse_feature_data)
        reverse_feature_data = self.domain_fcn2(reverse_feature_data)
        reverse_feature_data = self.domain_fcn3(reverse_feature_data)
        reverse_feature_data = self.domain_fcn4(reverse_feature_data)
        reverse_feature_data = self.domain_sig(reverse_feature_data)
        data_domain_pred = reverse_feature_data.view(reverse_feature_data.size(0), -1)  # torch.Size([64, 1])

        return data_probs_pred, data_domain_pred


class st_gcn(nn.Module):
    r"""Applies a spatial temporal graph convolution over an input graph sequence.

    Args:
        in_channels (int): Number of channels in the input sequence data
        out_channels (int): Number of channels produced by the convolution
        kernel_size (tuple): Size of the temporal convolving kernel and graph convolving kernel
        stride (int, optional): Stride of the temporal convolution. Default: 1
        dropout (int, optional): Dropout rate of the final output. Default: 0
        residual (bool, optional): If ``True``, applies a residual mechanism. Default: ``True``

    Shape:
        - Input[0]: Input graph sequence in :math:`(N, in_channels, T_{in}, V)` format
        - Input[1]: Input graph adjacency matrix in :math:`(K, V, V)` format
        - Output[0]: Outpu graph sequence in :math:`(N, out_channels, T_{out}, V)` format
        - Output[1]: Graph adjacency matrix for output data in :math:`(K, V, V)` format

        where
            :math:`N` is batch size,
            :math:`K` is the spatial kernel size, as :math:`K == kernel_size[1]`,
            :math:`T_{in}/T_{out}` is a length of input/output sequence,
            :math:`V` is the number of graph nodes.

    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,  # (11, 1)
                 stride=1,
                 dropout=0.5,
                 residual=True):
        super().__init__()
        # print("Dropout={}".format(dropout))
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        padding = ((kernel_size[0] - 1) // 2, 0)  # padding = (5, 0)

        self.gcn = ConvTemporalGraphical(in_channels, out_channels, kernel_size[1])  # kernel_size[1] = 1

        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(
                out_channels,
                out_channels,
                (kernel_size[0], 1),  # kernel_size[0] = 11
                (stride, 1),
                padding,
            ),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if not residual:
            self.residual = lambda x: 0

        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x

        else:
            self.residual = nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=1,
                    stride=(stride, 1)),
                nn.BatchNorm2d(out_channels),
            )

        self.relu = nn.ReLU(inplace=True)  # original paper
        # self.tanh = nn.Tanh()  # modified by yuqi-20210715

    def forward(self, x, A):  # x.shape: torch.Size([64, 1, 128, 22])
        res = self.residual(x)
        x, A = self.gcn(x, A)  # x.shape: torch.Size([64, 64, 128, 22])
        x = self.tcn(x) + res  # x.shape: torch.Size
        return self.relu(x), A  # original paper
        # return self.tanh(x), A  # modified by yuqi 2021-07-15


class pre_Model(nn.Module):
    r"""Spatial temporal graph convolutional networks.

    Args:
        in_channels (int): Number of channels in the input data
        num_class (int): Number of classes for the classification task
        edge_importance_weighting (bool): If ``True``, adds a learnable
            importance weighting to the edges of the graph
        **kwargs (optional): Other parameters for graph convolution units

    Shape:
        - Input: :math:`(N, in_channels, T_{in}, V_{in}, M_{in})`
        - Output: :math:`(N, num_class)` wheretorch.nn
            :math:`N` is batch size,
            :math:`T_{in}` is a length of input sequence,
            :math:`V_{in}` is the number of graph nodes,
            :math:`M_{in}` is the number of instance in a frame.
    """

    def __init__(self, in_channels, num_class, edge_importance_weighting, **kwargs) -> object:
        super().__init__()

        # load adjacent matrix A, A needs to add the identity matrix, that is, diagonal of A should be 1.
        # A = np.ones([116, 116])
        # a1_adj_matrix_pc_aal.npy
        # a2_adj_matrix_SR_aal.npy
        # a3_adj_matrix_global_aal.npy
        # a4_adj_matrix_global_topk_aal.npy
        # a5_adj_matrix_pc_topk_aal.npy
        # A = np.load('/shenlab/lab_stor4/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/a1_adj_matrix_pc_aal.npy')
        A = np.load('/home/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/a1_adj_matrix_pc_aal.npy')

        Dl = np.sum(A, 0)
        num_node = A.shape[0]
        Dn = np.zeros((num_node, num_node))
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A), Dn)  # DAD.shape: (node_num, node_num)

        temp_matrix = np.zeros((1, A.shape[0], A.shape[0]))
        temp_matrix[0] = DAD
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A)  # A.shape: torch.Size([1, node_num, node_num])

        # build networks (number of layers, final output features, kernel size)
        spatial_kernel_size = A.size(0)  # spatial_kernel_size = 1**
        temporal_kernel_size = 11  # update temporal kernel size
        kernel_size = (temporal_kernel_size, spatial_kernel_size)  # kernel_size = (11, 1)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}  # kwargs0: {}
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 16, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            # st_gcn(64, 128, kernel_size, 2, **kwargs),
            # st_gcn(128, 128, kernel_size, 1, **kwargs),
            # st_gcn(128, 128, kernel_size, 1, **kwargs),
            # st_gcn(128, 256, kernel_size, 2, **kwargs),
            # st_gcn(256, 256, kernel_size, 1, **kwargs),
            # st_gcn(256, 256, kernel_size, 1, **kwargs),
        ))

        # initialize parameters for edge importance weighting
        if edge_importance_weighting:
            self.edge_importance = nn.ParameterList([
                nn.Parameter(torch.ones(self.A.size()))
                for i in self.st_gcn_networks
            ])
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)  # output: [1, 1, 1, 1, ...]

        # fcn for prediction (**number of fully connected layers**)
        self.cls_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.cls_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.cls_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.cls_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.cls_sig = nn.Sigmoid()

        self.domain_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.domain_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.domain_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.domain_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.domain_sig = nn.Sigmoid()

    def forward(self, source, tgt1, tgt2, alpha_src, alpha_tgt1, alpha_tgt2):  # x.shape: torch.Size([bs, 1, 200, 116, 1]), where 64 is batch size
        N_src, C, T, V, M = source.size()  # N=bs, C=1, T=W(e.g., 200), V=116, M=1
        source = source.permute(0, 4, 3, 1, 2).contiguous()  # torch.Size([bs, 1, 116, 1, 200])
        source = source.view(N_src * M, V * C, T)  # torch.Size([bs*1, 116*1, 200])
        source = self.data_bn(source.float())  # torch.Size([bs*1, 116*1, 200])
        source = source.view(N_src, M, V, C, T)  # torch.Size([bs, 1, 116, 1, 200])
        source = source.permute(0, 1, 3, 4, 2).contiguous()  # torch.Size([bs, 1, 1, 200, 116])
        source = source.view(N_src * M, C, T, V)  # torch.Size(1*bs, 1, 200, 116])

        N_tgt1, C, T, V, M = tgt1.size()  # N=bs, C=1, T=W(e.g., 200), V=116, M=1
        tgt1 = tgt1.permute(0, 4, 3, 1, 2).contiguous()  # torch.Size([bs, 1, 116, 1, 200])
        tgt1 = tgt1.view(N_tgt1 * M, V * C, T)  # torch.Size([bs*1, 116*1, 200])
        tgt1 = self.data_bn(tgt1.float())  # torch.Size([bs*1, 116*1, 200])
        tgt1 = tgt1.view(N_tgt1, M, V, C, T)  # torch.Size([bs, 1, 116, 1, 200])
        tgt1 = tgt1.permute(0, 1, 3, 4, 2).contiguous()  # torch.Size([bs, 1, 1, 200, 116])
        tgt1 = tgt1.view(N_tgt1 * M, C, T, V)  # torch.Size(1*bs, 1, 200, 116])

        N_tgt2, C, T, V, M = tgt2.size()  # N=bs, C=1, T=W(e.g., 200), V=116, M=1
        tgt2 = tgt2.permute(0, 4, 3, 1, 2).contiguous()  # torch.Size([bs, 1, 116, 1, 200])
        tgt2 = tgt2.view(N_tgt2 * M, V * C, T)  # torch.Size([bs*1, 116*1, 200])
        tgt2 = self.data_bn(tgt2.float())  # torch.Size([bs*1, 116*1, 200])
        tgt2 = tgt2.view(N_tgt2, M, V, C, T)  # torch.Size([bs, 1, 116, 1, 200])
        tgt2 = tgt2.permute(0, 1, 3, 4, 2).contiguous()  # torch.Size([bs, 1, 1, 200, 116])
        tgt2 = tgt2.view(N_tgt2 * M, C, T, V)  # torch.Size(1*bs, 1, 200, 116])

        for gcn, importance in zip(self.st_gcn_networks, self.edge_importance):
            source, _ = gcn(source, self.A * importance)  # [bs, 16, 200, 116]
            tgt1, _ = gcn(tgt1, self.A * importance)  # [bs, 16, 200, 116]
            tgt2, _ = gcn(tgt2, self.A * importance)  # [bs, 16, 200, 116]

        # ------------------------------------------------------------------------------
        source = source.mean(axis=3)  # [bs, 16, 200]
        feature_src = source.view(source.size(0), -1)

        # class prediction (src)
        source = source.view(source.size(0), -1)  # [bs, 3200]
        source = source.view(N_src, M, -1, 1, 1).mean(dim=1)
        source = self.cls_fcn1(source)
        source = self.cls_fcn2(source)
        source = self.cls_fcn3(source)
        source = self.cls_fcn4(source)
        source = self.cls_sig(source)
        source_pred = source.view(source.size(0), -1)  # torch.Size([64, 1])

        # class prediction (src)
        reverse_feature_src = ReverseLayerF.apply(feature_src, alpha_src)  # feature should be (bs, xxx)
        reverse_feature_src = reverse_feature_src.view(N_src, M, -1, 1, 1).mean(dim=1)  # torch.Size([64, xx])
        reverse_feature_src = self.domain_fcn1(reverse_feature_src)
        reverse_feature_src = self.domain_fcn2(reverse_feature_src)
        reverse_feature_src = self.domain_fcn3(reverse_feature_src)
        reverse_feature_src = self.domain_fcn4(reverse_feature_src)
        reverse_feature_src = self.domain_sig(reverse_feature_src)
        src_domain_pred = reverse_feature_src.view(reverse_feature_src.size(0), -1)  # torch.Size([64, 1])

        # ------------------------------------------------------------------------------
        tgt1 = tgt1.mean(axis=3)  # [bs, 16, 200]
        feature_tgt1 = tgt1.view(tgt1.size(0), -1)

        # class prediction (tgt1)
        tgt1 = tgt1.view(tgt1.size(0), -1)  # [bs, 3200]
        tgt1 = tgt1.view(N_tgt1, M, -1, 1, 1).mean(dim=1)
        tgt1 = self.cls_fcn1(tgt1)
        tgt1 = self.cls_fcn2(tgt1)
        tgt1 = self.cls_fcn3(tgt1)
        tgt1 = self.cls_fcn4(tgt1)
        tgt1 = self.cls_sig(tgt1)
        tgt1_pred = tgt1.view(tgt1.size(0), -1)  # torch.Size([64, 1])

        # class prediction (tgt1)
        reverse_feature_tgt1 = ReverseLayerF.apply(feature_tgt1, alpha_tgt1)  # feature should be (bs, xxx)
        reverse_feature_tgt1 = reverse_feature_tgt1.view(N_tgt1, M, -1, 1, 1).mean(dim=1)  # torch.Size([64, xx])
        reverse_feature_tgt1 = self.domain_fcn1(reverse_feature_tgt1)
        reverse_feature_tgt1 = self.domain_fcn2(reverse_feature_tgt1)
        reverse_feature_tgt1 = self.domain_fcn3(reverse_feature_tgt1)
        reverse_feature_tgt1 = self.domain_fcn4(reverse_feature_tgt1)
        reverse_feature_tgt1 = self.domain_sig(reverse_feature_tgt1)
        tgt1_domain_pred = reverse_feature_tgt1.view(reverse_feature_tgt1.size(0), -1)  # torch.Size([64, 1])

        # ------------------------------------------------------------------------------
        tgt2 = tgt2.mean(axis=3)  # [bs, 16, 200]
        feature_tgt2 = tgt2.view(tgt2.size(0), -1)

        # class prediction (tgt2)
        tgt2 = tgt2.view(tgt2.size(0), -1)  # [bs, 3200]
        tgt2 = tgt2.view(N_tgt2, M, -1, 1, 1).mean(dim=1)
        tgt2 = self.cls_fcn1(tgt2)
        tgt2 = self.cls_fcn2(tgt2)
        tgt2 = self.cls_fcn3(tgt2)
        tgt2 = self.cls_fcn4(tgt2)
        tgt2 = self.cls_sig(tgt2)
        tgt2_pred = tgt2.view(tgt2.size(0), -1)  # torch.Size([64, 1])

        # class prediction (tgt2)
        reverse_feature_tgt2 = ReverseLayerF.apply(feature_tgt2, alpha_tgt2)  # feature should be (bs, xxx)
        reverse_feature_tgt2 = reverse_feature_tgt2.view(N_tgt2, M, -1, 1, 1).mean(dim=1)  # torch.Size([64, xx])
        reverse_feature_tgt2 = self.domain_fcn1(reverse_feature_tgt2)
        reverse_feature_tgt2 = self.domain_fcn2(reverse_feature_tgt2)
        reverse_feature_tgt2 = self.domain_fcn3(reverse_feature_tgt2)
        reverse_feature_tgt2 = self.domain_fcn4(reverse_feature_tgt2)
        reverse_feature_tgt2 = self.domain_sig(reverse_feature_tgt2)
        tgt2_domain_pred = reverse_feature_tgt2.view(reverse_feature_tgt2.size(0), -1)  # torch.Size([64, 1])

        return source_pred, tgt1_pred, tgt2_pred, src_domain_pred, tgt1_domain_pred, tgt2_domain_pred


if __name__ == "__main__":

    src_data = torch.ones(128, 1, 200, 116, 1).double()
    tgt_data = torch.ones(128, 1, 200, 116, 1).double()
    net_yq_model = pre_Model(1, 1, edge_importance_weighting=True)
    result, mmd_loss = net_yq_model(src_data, tgt_data)
    print('result.shape：', result.shape)  # torch.Size([64, 1])
    print('mmd_loss：', mmd_loss)

    net_yq_premodel = pre_Model(1, 1, edge_importance_weighting=True)
    result = net_yq_premodel(src_data)
    print('result.shape：', result.shape)  # torch.Size([64, 1])
