from __future__ import print_function
import warnings
warnings.filterwarnings('ignore')

import math
import torch
from dataset_prep import Dataset_MMD
from torch.utils.data import DataLoader
from sklearn.metrics import confusion_matrix
from torch import nn
from torch import optim
from net.st_gcn import Model_tea1
import random
import numpy as np
from sklearn.metrics import roc_auc_score
import visdom
import torch.nn.functional as F


def step_decay(epoch, learning_rate, drop, epochs_drop):
    """
    learning rate step decay
    :param epoch: current training epoch
    :param learning_rate: initial learning rate
    :return: learning rate after step decay
    """
    initial_lrate = learning_rate
    lrate = initial_lrate * math.pow(drop, math.floor((1 + epoch) / epochs_drop))
    return lrate


def pretrain_tea1(epoch, ddcnet_tea1, src_loader, tgt1_train_loader, learning_rate, drop, epochs_drop):
    log_interval = 1
    LEARNING_RATE = step_decay(epoch, learning_rate, drop, epochs_drop)
    print(f'Learning Rate: {LEARNING_RATE}')
    tea1_optimizer = optim.SGD(ddcnet_tea1.parameters(), lr=LEARNING_RATE, momentum=MOMENTUM, weight_decay=L2_DECAY)
    tea1_class_clf_criterion = nn.BCELoss()
    tea1_domain_clf_criterion = nn.BCELoss()
    ddcnet_tea1.train()

    train_correct = 0
    train_loss = 0
    TN = 0
    FP = 0
    FN = 0
    TP = 0

    tr_tea1_src_auc_gt = []
    tr_tea1_src_auc_pred = []

    len_dataloader = min(len(src_loader), len(tgt1_train_loader))
    for step, (src_batch, tgt1_batch) in enumerate(zip(src_loader, tgt1_train_loader)):
        p = float(step + epoch * len_dataloader) / TRAIN_EPOCHS / len_dataloader
        # alpha_reverse = 2. / (1. + np.exp(-10 * p)) - 1  # original
        alpha = 2. / (1. + np.exp(-1 * p)) - 1
        print('p:', p)

        tea1_optimizer.zero_grad()
        src_data_batch = src_batch['data'].to(device).float()
        src_label_batch = src_batch['label'].to(device).float()
        tgt1_data_batch = tgt1_batch['data'].to(device).float()

        # supervised learning using src data and src label
        tea1_src_pred, tea1_src_domain = ddcnet_tea1(src_data_batch, alpha)
        tea1_clf_loss = tea1_class_clf_criterion(tea1_src_pred[:, 0], src_label_batch)

        # adversarial training, check input come from which domain.
        tea1_src_domain_label = torch.zeros(BATCH_SIZE).to(device)
        tea1_loss_s_domain = tea1_domain_clf_criterion(tea1_src_domain[:, 0], tea1_src_domain_label)

        _, tea1_tgt1_domain = ddcnet_tea1(tgt1_data_batch, alpha)
        tea1_tgt1_domain_label = torch.ones(BATCH_SIZE).to(device)
        tea1_loss_t_domain = tea1_domain_clf_criterion(tea1_tgt1_domain[:, 0], tea1_tgt1_domain_label)

        tea1_loss = tea1_clf_loss + 1 * (tea1_loss_s_domain + tea1_loss_t_domain)  # total loss = (1) classification loss + (2) adversarial loss

        tea1_loss.backward()
        tea1_optimizer.step()
        train_loss += tea1_loss

        tea1_src_pred_cpu = tea1_src_pred.data.cpu().numpy() > 0.5
        train_correct += sum(tea1_src_pred_cpu[:, 0] == src_label_batch.cpu().numpy())  # correct num in one batch

        TN_tmp, FP_tmp, FN_tmp, TP_tmp = confusion_matrix(src_label_batch.cpu().numpy(), tea1_src_pred_cpu[:, 0], labels=[0, 1]).ravel()
        TN += TN_tmp
        FP += FP_tmp
        FN += FN_tmp
        TP += TP_tmp

        # tr auc
        tr_tea1_src_auc_gt.extend(src_label_batch.cpu().numpy())
        tr_tea1_src_auc_pred.extend(tea1_src_pred.detach().cpu().numpy())

        if (step + 1) % log_interval == 0:
            print("Train Epoch [{:4d}/{}] Step [{:2d}/{}]: clf_loss={:.6f}, src_adv_loss={:.6f}, tgt_adv_loss={:.6f}, loss={:.6f}".format(
                    epoch, TRAIN_EPOCHS, step + 1, len_dataloader, tea1_clf_loss.data, tea1_loss_s_domain.data, tea1_loss_t_domain, tea1_loss.data))

    train_loss /= len_dataloader
    train_acc = (TP+TN) / (TP + FP + TN + FN)
    # train_acc = float(train_correct) * 100.0 / (len_dataloader * BATCH_SIZE)  # another way to compute 'train_acc'
    train_F1 = (2 * TP) / (2 * TP + FP + TN)

    train_AUC = roc_auc_score(tr_tea1_src_auc_gt, tr_tea1_src_auc_pred)

    print('Train set: Average classification loss: {:.4f}, Accuracy: {}/{} ({:.2f}%), train_AUC: {:.5}, train_F1: {:.5}'.format(
        train_loss, train_correct, (len_dataloader * BATCH_SIZE), train_acc, train_AUC, train_F1))

    # save checkpoint.pth, save train loss and acc to a txt file
    if epoch == 30 or epoch == 40:
        torch.save(ddcnet_tea1.state_dict(), SAVE_PATH + 'fold_' + str(fold) + '_epoch_' + str(epoch) + '.pth')
    with open(SAVE_PATH + 'fold_' + str(fold) + '_train_loss_and_acc.txt', 'a') as f:
        f.write('epoch {}, loss {:.5}, train acc {:.5}, train_AUC {:.5}, train_F1 {:.5}\n'.format(epoch, train_loss, train_acc, train_AUC, train_F1))


def test_ddcnet(ddcnet_tea1, test_loader) -> object:
    with torch.no_grad():

        ddcnet_tea1.eval()
        test_correct = 0
        TN = 0
        FP = 0
        FN = 0
        TP = 0
        te_tea1_auc_gt = []
        te_tea1_auc_pred = []

        for step, test_sample_batch in enumerate(test_loader):
            test_data_batch = test_sample_batch['data'].to(device).float()
            test_label_batch = test_sample_batch['label'].to(device).float()

            # three outputs should be the same
            tea1_tgt_pred, _ = ddcnet_tea1(test_data_batch, 0)

            test_pred_cpu = tea1_tgt_pred.data.cpu().numpy() > 0.5
            test_correct += sum(test_pred_cpu[:, 0] == test_label_batch.cpu().numpy())
            TN_tmp, FP_tmp, FN_tmp, TP_tmp = confusion_matrix(test_label_batch.cpu().numpy(), test_pred_cpu[:, 0], labels=[0, 1]).ravel()
            TN += TN_tmp
            FP += FP_tmp
            FN += FN_tmp
            TP += TP_tmp

            te_tea1_auc_gt.extend(test_label_batch.cpu().numpy())
            te_tea1_auc_pred.extend(tea1_tgt_pred.detach().cpu().numpy())

        TPR = TP / (TP + FN)  # Sensitivity/ hit rate/ recall/ true positive rate
        TNR = TN / (TN + FP)  # Specificity/ true negative rate
        PPV = TP / (TP + FP)  # Precision/ positive predictive value
        NPV = TN / (TN + FN)  # Negative predictive value
        FPR = FP / (FP + TN)  # Fall out/ false positive rate
        FNR = FN / (TP + FN)  # False negative rate
        FDR = FP / (TP + FP)  # False discovery rate
        test_acc = (TP+TN) / (TP + FP + TN + FN)  # accuracy of each class
        # test_acc = float(test_correct) * 100. / len(test_loader)  # another way to compute 'test_acc'
        test_F1 = (2 * TP) / (2 * TP + FP + TN)
        test_AUC = roc_auc_score(te_tea1_auc_gt, te_tea1_auc_pred)

        print('Test set: Correct_num: {}, test_acc: {:.4f}, test_AUC: {:.4f}, test_F1: {:.4f}, TPR: {:.4f}, TNR: {:.4f}, PPV:{:.4f}, NPV: {:.4f}, FPR: {:.4f}, FNR: {:.4f}, FDR: {:.4f}'.format(
            test_correct, test_acc, test_AUC, test_F1, TPR, TNR, PPV, NPV, FPR, FNR, FDR))

        # save test loss and acc to a txt file
        with open(SAVE_PATH + flag + '_fold_' + str(fold) + '_test_loss_and_acc.txt', 'a') as f:
            f.write('epoch {}, test_acc {:.5}, test_AUC {:.5}, test_F1: {:.4f}, TPR {:.5}, TNR {:.5}, PPV {:.5}, NPV {:.5}, FPR {:.5}, FNR {:.5}, FDR {:.5}\n'.format(epoch, test_acc, test_AUC, test_F1, TPR, TNR, PPV, NPV, FPR, FNR, FDR))


if __name__ == '__main__':
    # m1_preprocess_raw
    # m2_preprocess_norm_allROI_eachsubj
    # m3_preprocess_norm_eachROI_eachsubj
    # m4_preprocess_norm_eachROI_allsubj

    # ROOT_PATH = '/home/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/'
    # SAVE_PATH = '/home/yuqifang/projects/MICCAI2022_summary/multarget_code/MFH/s1_pretrain_tea1_tea2_stu/pretrain_tea1/checkpoints_pretrain_tea1/'

    ROOT_PATH = '/shenlab/lab_stor4/yuqifang/projects/MICCAI2022/multarget_data/npy_src_20_tgt1_21_tgt2_1/'
    SAVE_PATH = '/shenlab/lab_stor4/yuqifang/projects/MICCAI2022_summary/multarget_code/MFH/s1_pretrain_tea1_tea2_stu/pretrain_tea1/checkpoints_pretrain_tea1/'

    BATCH_SIZE = 128
    TRAIN_EPOCHS = 50
    L2_DECAY = 5e-4
    MOMENTUM = 0.9
    learning_rate = 0.1
    drop = 0.5
    epochs_drop = 30.0
    TEST_BATCH_SIZE = 128

    for fold in [3, 8, 9, 13, 30]:
        seed = fold  # fold
        np.random.seed(seed)
        random.seed(seed)
        torch.manual_seed(seed)  # cpu
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True  # cpu/gpu结果一致

        print('Load data begin:')
        src_data = ROOT_PATH + 'src_data_aal.npy'  # (srcsubj_num, 1, T, node_num, 1)
        src_label = ROOT_PATH + 'src_label.npy'  # (srcsubj_num,)
        tgt1_data = ROOT_PATH + 'tgt1_data_aal.npy'  # (tgt1subj_num, 1, T, node_num, 1)
        tgt1_label = ROOT_PATH + 'tgt1_label.npy'  # (tgt1subj_num,)

        src_dataset = Dataset_MMD(src_data, src_label, transform=None)
        src_loader = DataLoader(src_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
        src_test_loader = DataLoader(src_dataset, batch_size=TEST_BATCH_SIZE, shuffle=False, drop_last=False)

        tgt1_dataset = Dataset_MMD(tgt1_data, tgt1_label, transform=None)
        tgt1_train_loader = DataLoader(tgt1_dataset, batch_size=BATCH_SIZE, shuffle=True, drop_last=True)
        tgt1_test_loader = DataLoader(tgt1_dataset, batch_size=TEST_BATCH_SIZE, shuffle=False, drop_last=False)

        device = torch.device("cuda:6" if torch.cuda.is_available() else "cpu")
        print('device:', device)

        ddcnet_tea1 = Model_tea1(in_channels=1, num_class=1, edge_importance_weighting=True).to(device)

        with open(SAVE_PATH + 'fold_' + str(fold) + '_train_loss_and_acc.txt', 'a') as f:
            f.write('total_epoch: {}, batch_size: {}, initial_lr {:.8}, drop_lr: {:.5}, drop_lr_per_epoch: {}\n'.format(TRAIN_EPOCHS, BATCH_SIZE, learning_rate, drop, epochs_drop))
        with open(SAVE_PATH + 'src_fold_' + str(fold) + '_test_loss_and_acc.txt', 'a') as f:
            f.write('total_epoch: {}, batch_size: {}, initial_lr {:.8}, drop_lr: {:.5}, drop_lr_per_epoch: {}\n'.format(TRAIN_EPOCHS, BATCH_SIZE, learning_rate, drop, epochs_drop))
        with open(SAVE_PATH + 'tgt1_fold_' + str(fold) + '_test_loss_and_acc.txt', 'a') as f:
            f.write('total_epoch: {}, batch_size: {}, initial_lr {:.8}, drop_lr: {:.5}, drop_lr_per_epoch: {}\n'.format(TRAIN_EPOCHS, BATCH_SIZE, learning_rate, drop, epochs_drop))

        for epoch in range(1, TRAIN_EPOCHS + 1):
            print(f'Train Epoch {epoch}:')
            pretrain_tea1(epoch, ddcnet_tea1, src_loader, tgt1_train_loader, learning_rate, drop, epochs_drop)
            flag = 'src'
            correct_src = test_ddcnet(ddcnet_tea1, src_test_loader)
            flag = 'tgt1'
            correct_tgt1 = test_ddcnet(ddcnet_tea1, tgt1_test_loader)

