# -*- coding: UTF-8 -*-
from __future__ import print_function, division
import os
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torchvision.transforms.functional as F
import numpy as np
import random


class Dataset_MMD(Dataset):
    def __init__(self, data_file, label_file, transform=None):
        self.data_file = data_file
        self.label_file = label_file
        self.transform = transform

    def __len__(self):
        subj_num = np.load(self.data_file).shape[0]
        return subj_num

    def __getitem__(self, idx):
        data = np.load(self.data_file)[idx, :, :, :, :]
        label = np.load(self.label_file)[idx]

        data = torch.from_numpy(data)
        label = torch.tensor(label)  # solution (1)
        # label = np.array(label)  # solution (2)
        # label = torch.from_numpy(label)

        # record the data from which site? then student&teacher models produce prediction outputs of each site:
        # student model: src_pred, tgt1_pred, tgt2_pred
        # teacher1 model: src_pred, tgt1_pred, _
        # teacher2 model: src_pred, _, tgt2_pred
        # return dictionary
        sample = {'data': data, 'label': label}  # data, label = sample['data'], sample['label']
        return sample


if __name__ == '__main__':
    data_dir = '/home/yuqifang/projects/DATA/npy_src_s20_and_tgt_s1/m1_preprocess_raw/src_data_aal.npy'
    label_dir = '/home/yuqifang/projects/DATA/npy_src_s20_and_tgt_s1/m1_preprocess_raw/src_label.npy'

    dataset = Dataset_MMD(data_dir, label_dir, transform=None)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True, num_workers=4, drop_last=True)

    # method 1 - enumerate
    for i_batch, sample_batched in enumerate(dataloader):
        print('i_batch:{}'.format(i_batch))
        print(i_batch, sample_batched['data'].shape, sample_batched['label'])

    # # method 2 - iter, next
    # iter_source = iter(dataloader)
    # num_iter = len(dataloader)
    # for i in range(1, num_iter):
    #     source_data = iter_source.next()['data']
    #     source_label = iter_source.next()['label']
    #     print('source_data:', source_data.shape)
    #     print('source_label:', source_label.shape)
